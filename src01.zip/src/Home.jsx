
import React from 'react'
import Product from './Addproduct'
import Nav from './Nav'


function Home() {
  return (
    <>
       <Nav />
      <Product />
      
    </>
  )
}

export default Home