import React,{useState} from 'react'



function Search({productdata}) {
    const [find, setfind] = useState('')
    const [searchResults, setSearchResults] = useState([])

    const handleSearch = () => {
        const res = productdata.filter((e) => 
          e.name.toLowerCase().includes(find.toLowerCase())  // Fixed the issues here
        );
        setSearchResults(res);
      };
  return (
   <>
   <div className="sarc">
   <input type="search" placeholder='search here'  value={find} onChange={(e)=>setfind(e.target.value)} />
   <button onClick={handleSearch}>Search</button>

    </div>
   <div className="field">
    <table>
        <thead>
            <tr>
                <th>PRODUCT NAME</th>
                <th>PRODUCT PRICE</th>
            </tr>
        </thead>
        <tbody>
           {
            searchResults.map((prod,index)=>(
                <tr key={index}>
                    <td>
                        {prod.name}

                    </td>
                    <td>RS {prod.price}</td>


                </tr>
            ))
           }

        </tbody>
    </table>
   </div>
  
   </>
  )
}

export default Search