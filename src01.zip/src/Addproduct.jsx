import React, { useState } from 'react';
import ProductList from './ProductList';
import Search from './Sarchbar';

const Product = () => {
  const [pdata, setpdata] = useState({ name: '', price: '' });
  const [productdata, setproduct] = useState([]);

  const handleproduct = (e) => {
    const { name, value } = e.target;
    setpdata({ ...pdata, [name]: value });
  };

  const addproduct = () => {
    const isDuplicate = productdata.some(
      (product) => product.name.toLowerCase() === pdata.name.toLowerCase()
    );

    if (isDuplicate) {
      alert('Product already exists!');
      return;
    }

    if (pdata.name && pdata.price) {
      setproduct([...productdata, pdata]);
      setpdata({ name: '', price: '' }); 
    } else {
      alert('Please fill in all fields!');
    }
  };

  const removeProduct = (index) => {
    const remove = productdata.filter((_, id) => id !== index);
    setproduct(remove);
  };

  return (
    <>
      <div id="inner">
        <input
          type="text"
          id="inp"
          value={pdata.name}
          onChange={handleproduct}
          name="name"
          placeholder="Product Name"
        />
        <br />
        <input
          type="text"
          id="inp"
          value={pdata.price}
          onChange={handleproduct}
          name="price"
          placeholder="Product Price"
        />
        <br />
        <button onClick={addproduct}>Add Product</button>
      </div>
      <ProductList productdata={productdata} removeProduct={removeProduct} />
      <Search productdata={productdata} />
    </>
  );
};

export default Product;
