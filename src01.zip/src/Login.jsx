import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";




const LoginPage = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      const response = await axios.post("https://reqres.in/api/login", {
        email: email,
        password: password,
      });
      localStorage.setItem("token", response.data.token);
      navigate("/home");
    } catch (err) {
      setError("Invalid email or password");
    }
  };

  // if (localStorage.getItem("token")) {
  //   navigate("/home");
  // }

  return (
    <div className="userlogin">
         <div className="log">
             <h1>Login</h1>
                <input className="em" type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)}/>
{/* email:"eve.holt@reqres.in",
   password:"tailwind" */}
      <input className="userpass" type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)}/>
      <button onClick={handleLogin}>Login</button>
      {error && <p>{error}</p>}
        </div>
    </div>
  );
};

export default LoginPage;